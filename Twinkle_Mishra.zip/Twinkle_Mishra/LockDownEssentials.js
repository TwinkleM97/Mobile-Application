const Order = require("./Order"); 

const OrderState = Object.freeze({
    WELCOMING: Symbol("welcoming"),
    OIL: Symbol("oil"),
    WIPERS: Symbol("wipers"),
    LIGHT_BULBS: Symbol("light_bulbs"),
    CAR_CLEANERS: Symbol("car_cleaners"),
    FLOOR_MATS: Symbol("floor_mats"),
    EXTRAS: Symbol("extras"),
    FINALIZE: Symbol("finalize")
});

module.exports = class LockDownEssentials extends Order {
    constructor(sNumber, sUrl) {
        super(sNumber, sUrl);
        this.stateCur = OrderState.WELCOMING;
        this.cart = {
            oil: 0,
            oilFilter: 0,
            wipers: 0,
            tires: 0,
            lightBulbs: 0,
            carCleaners: 0,
            floorMats: 0,
            sunGlasses: 0,
            phoneHolders: 0,
        };
        this.prices = {
            oil: 5.99,
            oilFilter: 7.99,
            wipers: 9.99,
            tires: 89.99,
            lightBulbs: 3.99,
            carCleaners: 5.99,
            floorMats: 20.99,
            sunGlasses: 10.99,
            phoneHolders: 5.99
        };
    }

    handleInput(sInput) {
        let aReturn = [];
        switch (this.stateCur) {
            case OrderState.WELCOMING:
                aReturn.push("Welcome to the Auto Parts Store!");
                aReturn.push(`For a list of what we sell, visit:`);
                aReturn.push(`${this.sUrl}/payment/${this.sNumber}/`);
                aReturn.push("Would you like to buy Engine Oil / Oil Filter or Both? (Press 1 for Yes, 2 for No, 3 for Both, 4 for No)");
                this.stateCur = OrderState.OIL;
                break;

            case OrderState.OIL:
                this.handleOilSelection(sInput, aReturn);
                break;

            case OrderState.WIPERS:
                this.handleWipersSelection(sInput, aReturn);
                break;

            case OrderState.LIGHT_BULBS:
                this.handleLightBulbsSelection(sInput, aReturn);
                break;

            case OrderState.CAR_CLEANERS:
                this.handleCarCleanersSelection(sInput, aReturn);
                break;

            case OrderState.FLOOR_MATS:
                this.handleFloorMatsSelection(sInput, aReturn);
                break;

            case OrderState.EXTRAS:
                this.handleExtrasSelection(sInput, aReturn);
                break;

            case OrderState.FINALIZE:
                this.finalizeOrder(aReturn);
                break;
        }
        return aReturn;
    }

    handleOilSelection(sInput, aReturn) {
        switch (sInput) {
            case '1':
                this.cart.oil += 1; // Oil
                break;
            case '2':
                this.cart.oilFilter += 1; // Oil Filter
                break;
            case '3':
                this.cart.oil += 1; // Both
                this.cart.oilFilter += 1;
                break;
            case '4':
                break;
            default:
                aReturn.push("Invalid input. Please press 1 for Engine Oil, 2 for Oil Filter, 3 for Both, or 4 for No.");
                return;
        }
        this.stateCur = OrderState.WIPERS;
        aReturn.push("Would you like to buy Wipers/Tires or Both? (Press 1 for Yes, 2 for Tires, 3 for Both, 4 for No)");
    }

    handleWipersSelection(sInput, aReturn) {
        switch (sInput) {
            case '1':
                this.cart.wipers += 1; // User selects Wipers
                break;
            case '2':
                this.cart.tires += 1; // User selects Oil Filter
                break;
            case '3':
                this.cart.wipers += 1; // User selects Both
                this.cart.tires += 1; 
                break;
            case '4':
                break; // User buy nothing
            default:
                aReturn.push("Invalid input. Please press 1 for Wipers, 2 for Tires, 3 for Both, or 4 for No.");
                return;
        }
        
        // Light Bulbs selection 
        this.stateCur = OrderState.LIGHT_BULBS; 
        aReturn.push("Would you like to buy Light Bulbs? (Press 1 for Yes, 2 for No)");
    }
    handleLightBulbsSelection(sInput, aReturn) {
        switch (sInput) {
            case '1':
                this.cart.lightBulbs += 1; // User selects Light Bulbs
                break;
            case '2':
                break;
            default:
                aReturn.push("Invalid input. Please press 1 for Light Bulbs or 2 for No");
                return;
        }
        this.stateCur = OrderState.CAR_CLEANERS;
        aReturn.push("Would you like to buy Car Cleaners? (Press 1 for Yes, 2 for No)");
    }

    handleCarCleanersSelection(sInput, aReturn) {
        switch (sInput) {
            case '1':
                this.cart.carCleaners += 1; // User selects Car Cleaners
                break;
            case '2':
                break;
            default:
                aReturn.push("Invalid input. Please press 1 for Car Cleaners or 2 for No.");
                return;
        }
        this.stateCur = OrderState.FLOOR_MATS;
        aReturn.push("Would you like to buy Floor Mats? (Press 1 for Yes, 2 for No)");
    }

    handleFloorMatsSelection(sInput, aReturn) {
        switch (sInput) {
            case '1':
                this.cart.floorMats += 1; // User selects Floor Mats
                break;
            case '2':
                break;
            default:
                aReturn.push("Invalid input. Please Press 1 for Floor Mats or 2 for No");
                return;
        }
        this.stateCur = OrderState.EXTRAS;
        aReturn.push("Would you like to buy Upsell Items? (Press 1 for Sunglasses, 2 for Phone Holders, 3 for Both, 4 for No)");
    }

    handleExtrasSelection(sInput, aReturn) {
        switch (sInput) {
            case '1':
                this.cart.sunGlasses += 1; // User selects Sunglasses
                break;
            case '2':
                this.cart.phoneHolders += 1; //User selects Phone Holders
                break;
            case '3':
                this.cart.sunGlasses += 1; // Both
                this.cart.phoneHolders += 1;
                break;
            case '4':
                break; //No
            default:
                aReturn.push("Invalid input. Please press 1 for Sunglasses, 2 for Phone Holders, 3 for Both, or 4 for No");
                return;
        }
        this.stateCur = OrderState.FINALIZE;
        aReturn.push("Thank you for your selections! Finalizing your order...");
        
        this.finalizeOrder(aReturn); // generating the bill summary 
    }
    
    finalizeOrder(aReturn) {
        aReturn.push("Order Summary:");
        let subtotal = 0;

        for (const item in this.cart) {
            if (this.cart[item] > 0) {
                const price = this.prices[item];
                const quantity = this.cart[item];
                const cost = price * quantity;
                subtotal += cost;
                aReturn.push(`${item.replace(/([A-Z])/g, ' $1').toLowerCase()} @ $${price.toFixed(2)} = $${cost.toFixed(2)}`);
            }
        }

        const tax = subtotal * 0.13; // 13% tax Ontario
        const total = subtotal + tax;

        aReturn.push(`Subtotal: $${subtotal.toFixed(2)}`);
        aReturn.push(`Tax (13%): $${tax.toFixed(2)}`);
        aReturn.push(`Total: $${total.toFixed(2)}`);
        aReturn.push(`We will text you from 519-222-2222 when your order is ready or if we have questions.`);
        this.isDone(true);
    }
//Generate Sign pdf 
    renderForm() {
        return(`
        <html>
        <head>
            <meta content="text/html; charset=UTF-8" http-equiv="content-type">
            <style type="text/css">
                ol {
                    margin: 0;
                    padding: 0;
                }
                table {
                    margin: 0 auto; 
                }
                table td,
                table th {
                    padding: 5pt;
                }
                .c1 {
                    border-right-style: solid;
                    border-bottom-color: #000000;
                    border-top-width: 1pt;
                    border-right-width: 1pt;
                    border-left-color: #000000;
                    vertical-align: top;
                    border-right-color: #000000;
                    border-left-width: 1pt;
                    border-top-style: solid;
                    border-left-style: solid;
                    border-bottom-width: 1pt;
                    width: 234pt;
                    border-top-color: #000000;
                    border-bottom-style: solid;
                }
                 .c13 {
                  color: #000000;
                  font-weight: 200;
                  text-decoration: none;
                  vertical-align: baseline;
                  font-size: 20pt;
                  font-family: "Arial";
                  font-style: normal
              }
      
                .c0 {
                    color: #000000;
                    font-weight: 400;
                    text-decoration: none;
                    vertical-align: baseline;
                    font-size: 20pt;
                    font-family: "Arial";
                    font-style: normal;
                    text-align: center; 
                }
                .c2 {
                    color: #000000;
                    font-weight: 400;
                    text-decoration: none;
                    vertical-align: baseline;
                    font-size: 11pt;
                    font-family: "Arial";
                    font-style: normal;
                    text-align: center;
                }
                .c9 {
                    padding-top: 12pt;
                    padding-bottom: 0pt;
                    line-height: 1.0;
                    orphans: 2;
                    widows: 2;
                    text-align: center;
                    height: 2pt;
                }
                .c10 {
                    text-align: center; 
                }
                .c12 {
                    padding-top: 12pt;
                    padding-bottom: 0pt;
                    line-height: 1.0;
                    orphans: 2;
                    widows: 2;
                    text-align: center; 
                }
                .c3 {
                    padding-top: 0pt;
                    padding-bottom: 0pt;
                    line-height: 1;
                    orphans: 2;
                    widows: 2;
                    text-align: center;
                }
                .c4 {
                    padding-top: 0pt;
                    padding-bottom: 7pt;
                    line-height: 1.15;
                    orphans: 2;
                    widows: 2;
                    text-align: center; 
                }
                .c8 {
                    padding-top: 0pt;
                    padding-bottom: 7pt;
                    line-height: 1;
                    orphans: 2;
                    widows: 2;
                    text-align: center;
                }
                .c11 {
                    border-spacing: 0;
                    border-collapse: collapse;
                    margin-right: auto;
                }
                .c5 {
                    background-color: #ffffff;
                    max-width: 468pt;
                    padding: 30pt;
                    text-align: center; 
                }
                .c6 {
                    height: 52pt;
                }
                .c15 {
                    font-size: 26pt;
                }
                .c14 {
                    height: 11pt;
                }
                .title {
                    padding-top: 0pt;
                    color: #000000;
                    font-size: 26pt;
                    padding-bottom: 3pt;
                    font-family: "Arial";
                    line-height: 1.15;
                    page-break-after: avoid;
                    orphans: 2;
                    widows: 2;
                    text-align: center;
                }
                .note {
                    color: #666666;
                    font-size: 11pt;
                    font-family: "Arial";
                    padding-top: 12pt;
                    text-align: center; 
                }
            </style>
        </head>
        <body class="c5">
            <p class="c3"><span class="c2">&nbsp;</span></p>
            <p class="c10"><span class="c0">For curbside pickup:</span></p>
           <p class="c12"><span class="c15">Text &ldquo;motor&rdquo; or &ldquo;gears&rdquo; to </span><span
                  class="c13">519-111-1111</span></p>
            <p class="c9"><span class="c2"></span></p>
            
            <table class="c11">
                <tbody>
                    <tr class="c7">
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c8"><span class="c0">Engine Oil 1L</span></p>
                        </td>
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c4"><span class="c0">5.99</span></p>
                        </td>
                    </tr>
                    <tr class="c6">
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c8"><span class="c0">Oil Filter</span></p>
                        </td>
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c4"><span class="c0">7.99</span></p>
                        </td>
                    </tr>
                    <tr class="c6">
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c8"><span class="c0">Wipers</span></p>
                        </td>
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c4"><span class="c0">9.99</span></p>
                        </td>
                    </tr>
                    <tr class="c6">
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c8"><span class="c0">Tires</span></p>
                        </td>
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c4"><span class="c0">89.99</span></p>
                        </td>
                    </tr>
                    <tr class="c6">
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c8"><span class="c0">Light Bulbs</span></p>
                        </td>
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c4"><span class="c0">3.99</span></p>
                        </td>
                    </tr>
                    <tr class="c6">
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c8"><span class="c0">Car Cleaners</span></p>
                        </td>
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c4"><span class="c0">5.99</span></p>
                        </td>
                    </tr>
                    <tr class="c6">
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c8"><span class="c0">Floor Mats</span></p>
                        </td>
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c4"><span class="c0">20.99</span></p>
                        </td>
                    </tr>
                    <tr class="c6">
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c8"><span class="c0">Sunglasses</span></p>
                        </td>
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c4"><span class="c0">10.99</span></p>
                        </td>
                    </tr>
                    <tr class="c6">
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c8"><span class="c0">Phone Holders</span></p>
                        </td>
                        <td class="c1" colspan="1" rowspan="1">
                            <p class="c4"><span class="c0">5.99</span></p>
                        </td>
                    </tr>
                </tbody>
            </table>
            
            <p class="c9"><span class="c2"></span></p>
            <p class="c12"><span class="c0">We also have a selection of accessories, motors, and tools.</span></p>
            <p class="c3 c14"><span class="c2"></span></p>
        </body>
        </html>
        `);
    }
}    