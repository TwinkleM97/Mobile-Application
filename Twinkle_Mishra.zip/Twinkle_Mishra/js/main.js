
import "https://code.jquery.com/jquery-1.12.1.min.js";
import IncomeTax from "./IncomeTax.js";

$(document).ready(() => {
  $("#calculate").click(() => {
    const income = parseFloat($("#income").val());
    const deducted = parseFloat($("#deducted").val());
    const taxCalculator = new IncomeTax();

    try {
      if (isNaN(income) || isNaN(deducted)) {
        throw new Error("Please enter valid numbers for income and tax deducted");
      }

      const federalTax = taxCalculator.calculateFederalTax(income);
      const ontarioTax = taxCalculator.calculateOntarioTax(income);
      const totalTax = federalTax + ontarioTax;
      const owing = totalTax - deducted;

      $("#federalTax").text(federalTax.toFixed(2));
      $("#ontarioTax").text(ontarioTax.toFixed(2));
      $("#totalTax").text(totalTax.toFixed(2));
      $("#owing").text(owing.toFixed(2));
    } catch (error) {
      
      alert(error.message);

      
      $("#federalTax").text("");
      $("#ontarioTax").text("");
      $("#totalTax").text("");
      $("#owing").text("");
    }
  });
});




