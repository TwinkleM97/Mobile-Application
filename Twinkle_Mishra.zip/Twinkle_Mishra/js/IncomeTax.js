class IncomeTax {
  calculateFederalTax(income) {
    if (income < 0) {
      throw new Error("Income cannot be negative");
    }
  
    let tax = 0;
  
    if (income <= 44701) {
      tax = income * 0.15;
    } else if (income <= 89401) {
      tax = 44701 * 0.15 + (income - 44701) * 0.22;
    } else if (income <= 138586) {
      tax = 44701 * 0.15 + (89401 - 44701) * 0.22 + (income - 89401) * 0.26;
    } else {
      tax = 44701 * 0.15 + (89401 - 44701) * 0.22 + (138586 - 89401) * 0.26 + (income - 138586) * 0.29;
    }
  
    return parseFloat(tax.toFixed(2)); 
  }
  calculateOntarioTax(income) {
    if (income < 0) {
      throw new Error("Income cannot be negative");
    }
    if (income <= 49231) {
      return parseFloat((income * 0.0505).toFixed(2));
    } else if (income <= 98463) {
      return parseFloat((49231 * 0.0505 + (income - 49231) * 0.0915).toFixed(2));
    } else if (income <= 150000) {
      return parseFloat((49231 * 0.0505 + (98463 - 49231) * 0.0915 + (income - 98463) * 0.1116).toFixed(2));
    } else if (income <= 220000) {
      return parseFloat((49231 * 0.0505 + (98463 - 49231) * 0.0915 + (150000 - 98463) * 0.1116 + (income - 150000) * 0.1216).toFixed(2));
    } else {
      return parseFloat((49231 * 0.0505 + (98463 - 49231) * 0.0915 + (150000 - 98463) * 0.1116 + (220000 - 150000) * 0.1216 + (income - 220000) * 0.1316).toFixed(2));
    }
  }

  calculateTotalTax(income) {
    const federalTax = this.calculateFederalTax(income);
    const ontarioTax = this.calculateOntarioTax(income);
    const totalTax = federalTax + ontarioTax;
    return parseFloat(totalTax.toFixed(2));
  }
}

export default IncomeTax;
