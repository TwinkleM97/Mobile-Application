import IncomeTax from "./IncomeTax.js";

QUnit.module("IncomeTax Tests", function () {
  // Federal Tax QUnit Tests
  QUnit.test("Federal Tax for income within the first bracket (15%)", function (assert) {
    const taxCalculator = new IncomeTax();

    // Income is $30,000, which falls in the first bracket (15%)
    const expected = (30000 * 0.15).toFixed(2); // Federal tax calc for $30,000
    assert.equal(
      taxCalculator.calculateFederalTax(30000),
      expected,
      `Federal tax for $30,000 should return ${expected}`
    );
  });

  QUnit.test("Federal Tax for income in the second bracket (22%)", function (assert) {
    const taxCalculator = new IncomeTax();

    // Income is $60,000, which falls partly in the first (15%) and second (22%) brackets
    const expected = (
      44701 * 0.15 + // Tax on the first $44,701
      (60000 - 44701) * 0.22 // Tax on the remaining $15,299
    ).toFixed(2);
    assert.equal(
      taxCalculator.calculateFederalTax(60000),
      expected,
      `Federal tax for $60,000 should return ${expected}`
    );
  });

  QUnit.test("Federal Tax for income in the third bracket (26%)", function (assert) {
    const taxCalculator = new IncomeTax();

    // Income is $100,000, which falls partly in the first (15%), second (22%), and third (26%) brackets
    const expected = (
      44701 * 0.15 + // Tax on the first $44,701
      (89401 - 44701) * 0.22 + // Tax on the next $44,700
      (100000 - 89401) * 0.26 // Tax on the remaining $10,599
    ).toFixed(2);
    assert.equal(
      taxCalculator.calculateFederalTax(100000),
      expected,
      `Federal tax for $100,000 should return ${expected}`
    );
  });

  QUnit.test("Federal Tax for income in the fourth bracket (29%)", function (assert) {
    const taxCalculator = new IncomeTax();

    // Income is $150,000, which falls into all four brackets (15%, 22%, 26%, and 29%)
    const expected = (
      44701 * 0.15 + // Taxes on the first $44,701
      (89401 - 44701) * 0.22 + // Taxes on the next $44,700
      (138586 - 89401) * 0.26 + // Taxes on the next $49,185
      (150000 - 138586) * 0.29 // Taxes on the remaining $11,414
    ).toFixed(2);
    assert.equal(
      taxCalculator.calculateFederalTax(150000),
      expected,
      `Federal tax for $150,000 should return ${expected}`
    );
  });

  QUnit.test("Federal Tax for boundary income ($44,701)", function (assert) {
    const taxCalculator = new IncomeTax();

    // Income is $44,701, which falls at the boundary of the first bracket
    const expected = (44701 * 0.15).toFixed(2); // All income is taxed at 15%
    assert.equal(
      taxCalculator.calculateFederalTax(44701),
      expected,
      `Federal tax for $44,701 should return ${expected}`
    );
  });


  // Ontario Tax Qunit Tests
  QUnit.test("Ontario Tax for income within the first bracket(5.05%)", function (assert) {
    const taxCalculator = new IncomeTax();

    // Income is $30,000, which falls in the first Ontario tax bracket (5.05%).
    //All income under $49,231 is taxed at 5.05%.
    const expected = (30000 * 0.0505).toFixed(2);
    assert.equal(
      taxCalculator.calculateOntarioTax(30000),
      expected,
      `Ontario tax for $30,000 should be ${expected}`
    );
  });

  QUnit.test("Ontario Tax for income in the second bracket(9.15% )", function (assert) {
    const taxCalculator = new IncomeTax();

    // Income is $60,000, which falls in the second Ontario tax bracket (9.15%).
    const expected = (49231 * 0.0505 + (60000 - 49231) * 0.0915).toFixed(2);
    assert.equal(
      taxCalculator.calculateOntarioTax(60000),
      expected,
      `Ontario tax for $60,000 should be ${expected}`
    );
  });

  QUnit.test("Ontario Tax for income in the third bracket(11.16%)", function (assert) {
    const taxCalculator = new IncomeTax();

    // Income is $100,000, which falls in the third Ontario tax bracket (11.16%).
    const expected = (
      49231 * 0.0505 +
      (98463 - 49231) * 0.0915 +
      (100000 - 98463) * 0.1116
    ).toFixed(2);
    assert.equal(
      taxCalculator.calculateOntarioTax(100000),
      expected,
      `Ontario tax for $100,000 should be ${expected}`
    );
  });

  QUnit.test("Ontario Tax for income in the fourth bracket (12.16%)", function (assert) {
    const taxCalculator = new IncomeTax();
  
    // Income is $200,000, which falls into the fourth bracket
    const expected = (
      49231 * 0.0505 + // First bracket
      (98463 - 49231) * 0.0915 + // Second bracket
      (150000 - 98463) * 0.1116 + // Third bracket
      (200000 - 150000) * 0.1216 // Fourth bracket
    ).toFixed(2);
  
    assert.equal(
      taxCalculator.calculateOntarioTax(200000),
      expected,
      `Ontario tax for $200,000 should be ${expected}`
    );
  });

  
  QUnit.test("Ontario Tax for income in the fifth bracket (13.16%)", function (assert) {
    const taxCalculator = new IncomeTax();
  
    // Income is $250,000, which falls into the fifth bracket
    const expected = (
      49231 * 0.0505 + // First bracket
      (98463 - 49231) * 0.0915 + // Second bracket
      (150000 - 98463) * 0.1116 + // Third bracket
      (220000 - 150000) * 0.1216 + // Fourth bracket
      (250000 - 220000) * 0.1316 // Fifth bracket
    ).toFixed(2);
  
    assert.equal(
      taxCalculator.calculateOntarioTax(250000),
      expected,
      `Ontario tax for $250,000 should be ${expected}`
    );
  });
  QUnit.test("Ontario Tax for boundary income ($49,231)", function (assert) {
    const taxCalculator = new IncomeTax();
    const expected = (49231 * 0.0505).toFixed(2); // Exact taxes for the first bracket
    assert.equal(
      taxCalculator.calculateOntarioTax(49231),
      expected,
      `Ontario tax for $49,231 should be ${expected}`
    );
  });

  // Total Tax Test
 QUnit.test("Total Tax for income of $100,000", function (assert) {
  const taxCalculator = new IncomeTax();

  // Expected federal and Ontario tax calculations
  const federalTax = (
    44701 * 0.15 +
    (89401 - 44701) * 0.22 +
    (100000 - 89401) * 0.26
  ).toFixed(2);

  const ontarioTax = (
    49231 * 0.0505 +
    (98463 - 49231) * 0.0915 +
    (100000 - 98463) * 0.1116
  ).toFixed(2);

  // Total tax is the sum of federal and Ontario taxes
  const expected = (parseFloat(federalTax) + parseFloat(ontarioTax)).toFixed(2);

  assert.equal(
    taxCalculator.calculateTotalTax(100000),
    expected,
    `Total tax for $100,000 should be ${expected}`
  );
});


  // Invalid Input Test
  QUnit.test("Federal Tax for invalid income (negative value)", function (assert) {
    const taxCalculator = new IncomeTax();
  
    assert.throws(
      () => taxCalculator.calculateFederalTax(-5000), 
      new Error("Income cannot be negative"), // Expected error message
      "Expected error: 'Income cannot be negative' when income is negative."
    );
  });
  
});
