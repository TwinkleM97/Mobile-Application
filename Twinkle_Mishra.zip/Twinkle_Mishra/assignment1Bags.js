const Order = require("./assignment1Order");

const OrderState = Object.freeze({
    WELCOMING: Symbol("welcoming"),
    ITEM_OPTION: Symbol("item_option"),
    JACKET_TYPE: Symbol("jacket_type"),
    JACKET_SIZE: Symbol("jacket_size"),
    JACKET_COLOUR: Symbol("jacket_colour"),
    PANTS_TYPE: Symbol("pants_type"),
    PANTS_SIZE: Symbol("pants_size"),
    PANTS_COLOUR: Symbol("pants_colour"),
    SUNGLASSES: Symbol("sunglasses"),
    ORDER_SUMMARY: Symbol("order_summary")
});

module.exports = class BagsOrder extends Order {
    constructor() {
        super();
        this.stateCur = OrderState.WELCOMING;
        this.sItemType = "";
        this.sSize = "";
        this.sColour = "";
        this.sSunglasses = "";
        this.orderSummary = [];
        this.selectedBoth = false; // Tracking if "both" is selected

        // Cost definitions:
        this.jacketCosts = {
            Blazer: 110,
            Leather: 90
        };
        this.pantsCosts = {
            Trousers: 60,
            Jeans: 75
        };
        this.sunglassesCost = 50;
        this.taxRate = 0.13; // Tax rate ON (13%)
    }

    handleInput(sInput) {
        let aReturn = [];
        switch (this.stateCur) {
            case OrderState.WELCOMING:
                this.stateCur = OrderState.ITEM_OPTION;
                aReturn.push("Welcome to Conestoga Apparels");
                aReturn.push("Would you like to order a Jacket, Pants, or Both?");
                break;

            case OrderState.ITEM_OPTION:
                if (sInput.toLowerCase() === "jacket") {
                    this.stateCur = OrderState.JACKET_TYPE;
                    aReturn.push("What kind of Jacket would you like? (Blazer/Leather)");
                } else if (sInput.toLowerCase() === "pants") {
                    this.stateCur = OrderState.PANTS_TYPE;
                    aReturn.push("What type of Pants would you like? (Trousers/Jeans)");
                } else if (sInput.toLowerCase() === "both") {
                    this.selectedBoth = true; // Tracking that both were selected
                    this.stateCur = OrderState.JACKET_TYPE;
                    aReturn.push("What type of Jacket would you like? (Blazer/Leather)");
                } else {
                    aReturn.push("Invalid data. Please choose either Jacket, Pants, or Both.");
                }
                break;

            case OrderState.JACKET_TYPE:
                if (sInput.toLowerCase() === "blazer" || sInput.toLowerCase() === "leather") {
                    this.sItemType = sInput.charAt(0).toUpperCase() + sInput.slice(1);
                    this.stateCur = OrderState.JACKET_SIZE;
                    aReturn.push(`What size would you like for your ${this.sItemType} Jacket?`);
                } else {
                    aReturn.push("Invalid data. Please choose either Blazer or Leather.");
                }
                break;

            case OrderState.JACKET_SIZE:
                this.sSize = sInput;
                this.stateCur = OrderState.JACKET_COLOUR;
                aReturn.push(`What colour would you like for your ${this.sItemType} Jacket?`);
                break;

            case OrderState.JACKET_COLOUR:
                this.sColour = sInput;
                this.orderSummary.push(`${this.sSize} ${this.sColour} ${this.sItemType} Jacket - $${this.jacketCosts[this.sItemType]}`);

                if (this.selectedBoth) {
                    this.stateCur = OrderState.PANTS_TYPE;
                    aReturn.push("What type of Pants would you like? (Trousers/Jeans)");
                } else {
                    this.stateCur = OrderState.SUNGLASSES;
                    aReturn.push("Would you like to add sunglasses to your order? (Yes/No)");
                }
                break;

            case OrderState.PANTS_TYPE:
                if (sInput.toLowerCase() === "trousers" || sInput.toLowerCase() === "jeans") {
                    this.sItemType = sInput.charAt(0).toUpperCase() + sInput.slice(1);
                    this.stateCur = OrderState.PANTS_SIZE;
                    aReturn.push(`What size would you like for your ${this.sItemType} Pants?`);
                } else {
                    aReturn.push("Invalid data. Please choose either Trousers or Jeans.");
                }
                break;

            case OrderState.PANTS_SIZE:
                this.sSize = sInput;
                this.stateCur = OrderState.PANTS_COLOUR;
                aReturn.push(`What colour would you like for your ${this.sItemType} Pants?`);
                break;

            case OrderState.PANTS_COLOUR:
                this.sColour = sInput;
                this.orderSummary.push(`${this.sSize} ${this.sColour} ${this.sItemType} Pants - $${this.pantsCosts[this.sItemType]}`);
                this.stateCur = OrderState.SUNGLASSES;
                aReturn.push("Would you like to add sunglasses to your order? (Yes/No)");
                break;

            case OrderState.SUNGLASSES:
                this.isDone(true);
                if (sInput.toLowerCase() === "no") {
                    this.sSunglasses = "No";
                    aReturn.push("No Sunglasses added");
                } else {
                    this.sSunglasses = "Yes";
                    this.orderSummary.push(`Sunglasses - $${this.sunglassesCost}`);
                }

                // Calculate total cost
                const itemCosts = this.orderSummary.reduce((acc, item) => {
                    const cost = parseFloat(item.match(/\$(\d+)/)[1]);
                    return acc + cost;
                }, 0);
                const tax = itemCosts * this.taxRate;
                const total = itemCosts + tax;

                // Order summary
                aReturn.push("Thank you for your order of:");
                this.orderSummary.forEach(item => aReturn.push(item));
                aReturn.push(`Tax (13%): $${tax.toFixed(2)}`);
                aReturn.push(`Total: $${total.toFixed(2)}`);

                let d = new Date();
                d.setMinutes(d.getMinutes() + 20);
                aReturn.push(`Please pick it up at ${d.toTimeString()}`);
                break;
        }

        return aReturn;
    }
}
