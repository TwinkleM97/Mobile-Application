const Order = require("./Order");

const OrderState = Object.freeze({
    WELCOMING:   Symbol("welcoming"),
    JACKET1: Symbol("jacket1"),
    JACKET1_SIZE: Symbol("jacket1_size"),
    JACKET1_COLOR: Symbol("jacket1_color"),
    ADD_JACKET: Symbol("add_jacket"),
    JACKET2_TYPE: Symbol("jacket2_type"),
    JACKET2_SIZE: Symbol("jacket2_size"),
    JACKET2_COLOR: Symbol("jacket2_color"),
    SUNGLASSES: Symbol("sunglasses"),
    PAYMENT: Symbol("payment")
});

module.exports = class ShwarmaOrder extends Order{
    constructor(sNumber, sUrl){
        super(sNumber, sUrl);
        this.stateCur = OrderState.WELCOMING;
        this.sJacket1 = "Leather";
        this.sJacket2 = "Denim";
        this.jacket1Size = "";
        this.jacket1Color = "";
        this.jacket2Size = "";
        this.jacket2Color = "";
        this.sSunglasses = "";
        this.nOrder = 0;
        this.tax = 0;
        this.total = 0;
        this.sItem ="jacket";
    }

    handleInput(sInput) {
      let aReturn = [];
      switch (this.stateCur) {
          case OrderState.WELCOMING:
              this.stateCur = OrderState.JACKET1;
              aReturn.push("Welcome to Conestoga Apparels!");
              aReturn.push("Would you like to buy a Jacket? (Press 1 for Leather, 2 for Denim)");
              break;
  
          case OrderState.JACKET1:
              if (sInput === "1" || sInput === "2") {
                  this.sJacket1 = sInput === "1" ? "Leather" : "Denim";
                  this.stateCur = OrderState.JACKET1_SIZE;
                  aReturn.push(`You've selected a ${this.sJacket1} jacket.`);
                  aReturn.push("What size would you like for your first jacket? (Press 1 for S, 2 for M, 3 for L, 4 for XL)");
              } else {
                  aReturn.push("Invalid data.. Please press 1 for Leather or 2 for Denim.");
              }
              break;
  
          case OrderState.JACKET1_SIZE:
              if (["1", "2", "3", "4"].includes(sInput)) {
                  this.jacket1Size = ["S", "M", "L", "XL"][sInput - 1]; // Convert input to size
                  this.stateCur = OrderState.JACKET1_COLOR;
                  aReturn.push(`You've selected size ${this.jacket1Size} for your first jacket.`);
                  aReturn.push("What color would you like for your first jacket?Please press 1 for White, 2 for Blue, or 3 for Black");
              } else {
                  aReturn.push("Invalid data.. Please press 1 for S, 2 for M, 3 for L, or 4 for XL.");
              }
              break;
  
              case OrderState.JACKET1_COLOR:
                if (sInput === "1" || sInput === "2" || sInput === "3") {
                    this.jacket1Color = sInput === "1" ? "White" : sInput === "2" ? "Blue" : "Black";
                    // Hard-coded jacket cost
                    this.jacket1Cost = this.sJacket1 === "Leather" ? 100 : 80;
                    this.nOrder += this.jacket1Cost; 
                    this.stateCur = OrderState.ADD_JACKET;
                    aReturn.push(`The cost for the ${this.sJacket1} jacket is $${this.jacket1Cost}.`);
                    aReturn.push("Would you like to add another jacket? (Yes/No)");
                } else {
                    aReturn.push("Invalid data.. Please press 1 for White, 2 for Blue, or 3 for Black.");
                }
                break;
  
          case OrderState.ADD_JACKET:
              if (sInput.toLowerCase() === "yes") {
                  this.stateCur = OrderState.JACKET2_TYPE;
                  aReturn.push("What type of jacket would you like for the second jacket? (Press 1 for Leather, 2 for Denim)");
              } else if (sInput.toLowerCase() === "no") {
                  this.stateCur = OrderState.SUNGLASSES;
                  this.sJacket2 = null; 
                  aReturn.push("Would you like to add sunglasses for $20? (Yes/No)");
              } else {
                  aReturn.push("Invalid data. Please enter Yes or No.");
              }
              break;
  
          case OrderState.JACKET2_TYPE:
              if (sInput === "1" || sInput === "2") {
                  this.sJacket2 = sInput === "1" ? "Leather" : "Denim";
                  this.stateCur = OrderState.JACKET2_SIZE;
                  aReturn.push(`You've selected a ${this.sJacket2} jacket.`);
                  aReturn.push("What size would you like for your second jacket? (Press 1 for S, 2 for M, 3 for L, 4 for XL)");
              } else {
                  aReturn.push("Invalid data.. Please press 1 for Leather or 2 for Denim.");
              }
              break;
  
          case OrderState.JACKET2_SIZE:
              if (["1", "2", "3", "4"].includes(sInput)) {
                  this.jacket2Size = ["S", "M", "L", "XL"][sInput - 1]; // Converting number input to size
                  this.stateCur = OrderState.JACKET2_COLOR;
                  aReturn.push(`You've selected size ${this.jacket2Size} for your second jacket.`);
                  aReturn.push("What color would you like for your second jacket?Press 1 for White, 2 for Blue, or 3 for Black");
              } else {
                  aReturn.push("Invalid data. Please press 1 for S, 2 for M, 3 for L, or 4 for XL.");
              }
              break;
  
              case OrderState.JACKET2_COLOR:
              if (sInput === "1" || sInput === "2" || sInput === "3") {
                  this.jacket2Color = sInput === "1" ? "White" : sInput === "2" ? "Blue" : "Black";
                  this.jacket2Cost = this.sJacket2 === "Leather" ? 100 : 80;
                  this.nOrder += this.jacket2Cost; // Add second jacket cost to total order
                  this.stateCur = OrderState.SUNGLASSES;
                  aReturn.push(`The cost for the ${this.sJacket2} jacket is $${this.jacket2Cost}.`);
                  aReturn.push("Would you like to add sunglasses for $20? (Yes/No)");
              } else {
                  aReturn.push("Invalid data. Please press 1 for White, 2 for Blue, or 3 for Black.");
              }
              break;
  
              case OrderState.SUNGLASSES:
    // Check for valid input
    if (sInput.toLowerCase() === "yes") {
        this.sSunglasses = "Sunglasses";
        this.sunglassesCost = 20;
        this.nOrder += this.sunglassesCost;
    } else if (sInput.toLowerCase() === "no") {
        this.sSunglasses = ""; // If the user decides not to add sunglasses, then Reset
    } else {
        // Invalid data. handling
        aReturn.push("Invalid data. Please respond with 'Yes' or 'No'.");
        return aReturn; 
    }
    
    this.stateCur = OrderState.PAYMENT;
    
    // Calculating tax and total
    const subtotal = this.nOrder;  // Storing the subtotal (without tax)
    this.tax = subtotal * 0.13;
    this.total = subtotal + this.tax;

    // Final invoice
    aReturn.push(`Thank you for your order:`);
    aReturn.push(`First Jacket: ${this.sJacket1}, Size: ${this.jacket1Size}, Color: ${this.jacket1Color}, Cost: $${this.jacket1Cost}`);
    
    // Only display second jacket if selected
    if (this.sJacket2) {
        aReturn.push(`Second Jacket: ${this.sJacket2}, Size: ${this.jacket2Size}, Color: ${this.jacket2Color}, Cost: $${this.jacket2Cost}`);
    }

    // Display sunglasses if selected
    if (this.sSunglasses) {
        aReturn.push(`Including : ${this.sSunglasses}, Cost: $${this.sunglassesCost}`);
    }
    
    aReturn.push(`Subtotal: $${subtotal.toFixed(2)}`); //Subtotal
    aReturn.push(`Tax (13%): $${this.tax.toFixed(2)}`); //Tax (13%) Ontario
    aReturn.push(`Total amount: $${this.total.toFixed(2)}`); // Total Cost with tax
    aReturn.push(`Please pay for your order here: ${this.sUrl}/payment/${this.sNumber}/`);
    break;
  
          case OrderState.PAYMENT:
            let DeliveryAddress=sInput.purchase_units?.[0]?.shipping;
              console.log(sInput, DeliveryAddress);
              this.isDone(true);
              let d = new Date();
              d.setMinutes(d.getMinutes() + 20);
              aReturn.push(`Your order will be delivered to ${DeliveryAddress.address.address_line_1}, ${DeliveryAddress.address.admin_area_2}, ${DeliveryAddress.address.admin_area_1}, ${DeliveryAddress.address.postal_code}, ${DeliveryAddress.address.country_code} at ${d.toTimeString()}`);
              break;
      }
      return aReturn;
  }
  
  renderForm(sTitle = "-1", sAmount = "-1"){
    
    if(sTitle != "-1"){
      this.sItem = sTitle;
    }
    if(sAmount != "-1"){
      this.nOrder = sAmount;
    }
    const sClientID =process.env.SB_CLIENT_ID || 'put your client id here for testing ... Make sure that you delete it before committing'
    
    return(`
    <!DOCTYPE html>

    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- Ensures optimal rendering on mobile devices. -->
      <meta http-equiv="X-UA-Compatible" content="IE=edge" /> <!-- Optimal Internet Explorer compatibility -->
    </head>
    
    <body>
      <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
      <script
        src="https://www.paypal.com/sdk/js?client-id=${sClientID}"> // Required. Replace SB_CLIENT_ID with your sandbox client ID.
      </script>
      Thank you ${this.sNumber} for your ${this.sItem} order of $${this.total.toFixed(2)}.
      <div id="paypal-button-container"></div>

      <script>
        paypal.Buttons({
            createOrder: function(data, actions) {
              // This function sets up the details of the transaction, including the amount and line item details.
              return actions.order.create({
                purchase_units: [{
                  amount: {
                    value: '${this.total.toFixed(2)}'
                  }
                }]
              });
            },
            onApprove: function(data, actions) {
              // This function captures the funds from the transaction.
              return actions.order.capture().then(function(details) {
                // This function shows a transaction success message to your buyer.
                $.post(".", details, ()=>{
                  window.open("", "_self");
                  window.close(); 
                });
              });
            }
        
          }).render('#paypal-button-container');
        // This function displays Smart Payment Buttons on your web page.
      </script>
    
    </body>
        
    `);

  }
}